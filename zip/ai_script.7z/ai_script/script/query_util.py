#!/usr/bin/python
#-*- encoding:utf8 -*-

import tlib.log as log
import tlib.auto as auto
from tlib import name
import urllib
import uuid
from tlib.path import home_path
from tlib.path import curr_path
from requestHelper import RequestHelper

import datetime
import json
import requests
import time

"""
@desc：query 处理函数
@date: 2017-11-21
@update:
    1) 新增未识别query和识别query沉淀 11-30
"""

AILAB_SUCCESS_QUERY = "pangu://AY-Shenma-SJL/arrival_skill_query/1"
AILAB_FAIL_QUERY = "pangu://AY-Shenma-SJL/arrival_skill_query/fail/1"


APP_ID_MAP= {
        "54aa2ff6-9179-11e7-b3c2-90e2bac40398": ["sys.nba"],
        "70a0bca4-9ce4-11e7-9fd9-6c92bf29f312": ["sys.xianxing", "sys.stock", "sys.currency", "sys.recipe", "sys.hq_qa", "sys.kg"],
        "8b051b94-9604-11e7-918e-90e2bac40398": ["sys.baike", "sys.hq_qa", "sys.kg"]
        }


def get_ailab_query(workspace, is_success=1, sep="`"):
    """
    获取天猫query
    """
    global AILAB_SUCCESS_QUERY,AILAB_FAIL_QUERY
    if is_success: 
        file_name = "success"
        cmd = "/apsara/deploy/pu cp %s %s" % (AILAB_SUCCESS_QUERY, file_name)
    else:
        file_name = "fail"
        cmd = "/apsara/deploy/pu cp %s %s" % (AILAB_FAIL_QUERY, file_name)
    log.info(cmd)
    status = auto.run(cmd, cwd=workspace, timeout=3600).status
    if status != 0:
        raise Exception("get pangu query fail")
    fr = open(workspace / file_name,  "r")
    lines = fr.readlines()
    lines = [line.strip().strip("\n") for line in lines]
    ####query 去重
    util = []
    temp_lines = []
    for line in lines:
        try:
            _list = line.split(sep)
            if len(_list) != 3:
                continue
            if _list[0] not in util:
                temp_lines.append(_list)
                util.append(_list[0])
        except:
            continue
    return temp_lines


def get_app_id(skill_name, map=APP_ID_MAP):
    #global APP_ID_MAP
    for k, v in map.items():
        if skill_name in v:
            return k
    return None

def get_app_skill_map(url="http://wm102530.proxy.taobao.org/wm102530/ai/query/arrival/app_info.txt"):
    map = {}
    try:
        r = requests.get(url, timeout=10)
        _dict = r.json()
        app_skills = _dict.get("app_skills")
        for app_id, value in app_skills.items():
            if app_id not in map:
                map[app_id] = []
            [map[app_id].append("%s.%s" % (x.get("type"), x.get("skill_name"))) for x in value]
    except:
        return None
    log.info(json.dumps(map, indent=4))
    return map


def construct_uri(querys, workspace, file_name, vendor="ai", token="ae564102bf9c17215fdcada65b942eb37e0f50c9"):
    global APP_ID_MAP
    session_id = str(uuid.uuid1()).replace("-", "")
    map = get_app_skill_map()
    if map is None:
        map = APP_ID_MAP 
    fw = open(workspace / file_name, "w")
    for query in querys: 
        try:
            q = urllib.quote(query[0])
            app_id = get_app_id(query[1], map=map)
            if app_id is None:
                log.info("skill_name:%s can not match app_id" % query[1])
                continue
            uri = "/query?session_id={}&query={}&app_id={}&vendor={}&token={}".format(session_id, q, app_id, vendor, token)
            fw.write("%s\n" % uri)
        except Exception as e:
            log.error(e)
            continue
    return True

def save_query(querys, press_query):
    """
        query 保存
    """
    pre = datetime.datetime.now().strftime("%Y-%m-%d") 
    _path = "/apsarapangu/disk1/xonline_runtime/wm102530/ai/query/arrival/"
    auto.run("cp %s %s/press_query/%s" % (press_query, _path, pre)) 
    with open("%s/skill_query/%s" % (_path, pre), "w") as f:
        f.write(json.dumps(querys, indent=4))

pre_dir = "/apsarapangu/disk1/xonline_runtime/wm102530/ai/query/arrival/skill_query/daily/"

def get_querys_from_ark(report_id=2194):
    """
    从ark报表中获取querys
    """
    now = datetime.datetime.now()
    delt = datetime.timedelta(days=-1)
    start_time = (now + delt).strftime("%Y%m%d%H")
    log.info(start_time)
    obj = RequestHelper()
    select_dims = ["query", "skill", "app_id", "intent", "vendor"]
    dim_filter = json.dumps([])
    data = []
    max_nums = 100000
    limit_start = 0
    step = 10000
    while 1:
        time.sleep(1)
        if limit_start >= max_nums:
            break
        obj.set_post_data(report_id, start_time=start_time, end_time=start_time, dim_filter=dim_filter, select_dims=select_dims, limit_start=limit_start, length=step)
        flag, result = obj.do_check()
        if not flag or len(result) == 0:
            log.error("get query fail from report_id:%s" % report_id)
            break
        data.extend(result.get("data"))
        limit_start += step
    querys = []
    try:
        [querys.append({"query": x[1], "skill_name": x[2], "app_id": x[3], "intent": x[4], "vendor": x[5], "token": ""}) for x in data]   
    except Exception as e:
        log.error(e)
    log.info(len(querys))
    return querys

def duplicate_remove(querys):
    """
    去重操作
    去重key: query_skill_name_intent_app_id    
    """
    util_map = {}
    for query in querys:
        try:
            key = "{}_{}_{}_{}".format(query.get("query").encode("utf8"), query.get("skill_name"), query.get("intent"), query.get("app_id"))
            if util_map.has_key(key):
                util_map[key]["pv"] +=  1
            else:
                util_map[key] = query
                util_map[key]["pv"] =  1
        except Exception as e:
            log.error(str(e))
            continue
    temp_lists = []
    [temp_lists.append(v) for k, v in util_map.items()] 
    log.info("before duplicate remove length: %s" % len(querys))
    log.info("after duplicate remove length: %s" % len(temp_lists))
    return temp_lists


def split_collects(querys):
    """
    集合分裂为success和fail
    success 正确识别技能
    fail 为正确识别技能
    """
    success_querys = []
    fail_querys = []
    for query in querys:
        skill_name = query.get("skill_name")
        if skill_name is None or skill_name == "":
            fail_querys.append(query)
        else:
            success_querys.append(query)
    return success_querys, fail_querys

def save_data(success_querys, fail_querys):
    """
    save data
    """
    global pre_dir
    pre = datetime.datetime.now().strftime("%Y-%m-%d")
    success = "%s%s_success.txt" % (pre_dir, pre)
    fail = "%s%s_fail.txt" % (pre_dir, pre)
    with open(success, "w") as f:
        f.write("%s\n" % json.dumps(success_querys, indent=4))
    with open(fail, "w") as f:
        f.write("%s\n" % json.dumps(fail_querys, indent=4))

if __name__ == "__main__":
    """
    case_name = name.get()
    workspace = home_path() / case_name
    log.info(workspace)
    workspace.makedirs()
    lines = get_ailab_query(workspace)
    log.info(lines[0])
    log.info(len(lines))
    construct_uri(lines, workspace, "uri")
    save_query(lines, workspace / "uri")
    """
    querys = get_querys_from_ark()
    dup_rm_querys = duplicate_remove(querys)
    success, fail = split_collects(dup_rm_querys)
    save_data(success, fail)





