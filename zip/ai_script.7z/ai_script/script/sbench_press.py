#!/usr/bin/python
#-*- encoding:utf8 -*-

import commands
import json
import time
import datetime


def modify_xml(**params):   
	"""
		修改sbench.xml配置
	"""
	for k, v in params.items():
		modify_cmd = "sed -i 's#<%s>.*</%s>#<%s>%s</%s>#' %s" % (k, k, k, v, k, "sbench.xml")
		try:
			status, output = commands.getstatusoutput(modify_cmd)
			if status != 0:
				print "error"
				return False	
		except Exception as e:
			print str(e)
			return False
	cp_cmd = "cp sbench.xml log/sbench.xml.%s" % params["qps"]
	status, output = commands.getstatusoutput(cp_cmd)
	return True


def exec_press():
	"""
		压测执行
	"""
	cmd = "./sbench -c sbench.xml"
	output = ""
	try:
		status, output = commands.getstatusoutput(cmd)
		if status != 0:
			return False, ""
	except Exception as e:
		print str(e)
		return False, ""
	return True, output

def run(init_qps=100, step=100, end_qps=500, sleep_time=10):
	"""
		开始执行压测
	"""
	fw = open("result.txt", "w")
	qps = init_qps
	while 1:
		time.sleep(sleep_time)
		if qps > end_qps:
			break
		flag = modify_xml(qps=qps)
		if not flag:
			fw.write("%s\n" % json.dumps({"set_qps": qps, "status": 0}))
			qps += step
			continue
		flag, output = False, None
		start_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
		flag, output = exec_press()	
		end_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
		try:
			if not flag:
				fw.write("%s\n" % json.dumps({"set_qps": qps, "status": 0}))
			else:
				result = None
				result = json.loads(output)
				result["set_qps"] = qps
				result["status"] = 1		
				result["start_time"] = start_time
				result["end_time"] = end_time
				fw.write("%s\n" % json.dumps(result))
		except Exception as e:
			print str(e)
			fw.write("%s\n" % json.dumps({"set_qps": qps, "status": 0}))
		qps += step

if __name__ == "__main__":
	#modify_xml(qps=100)
	run(init_qps=50, step=50, end_qps=400, sleep_time=120)
	
