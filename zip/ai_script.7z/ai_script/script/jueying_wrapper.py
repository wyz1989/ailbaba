#!/usr/bin/python
#-*- encoding:utf8 -*-
"""
@date: 2017-12-14
@desc: 绝影接口封装
@author: yizhong.wyz
"""

import tlib.log as log


import time
import json
import urllib
import requests

class JueYingWrapper():
    def __init__(self, aid="677", token="38BE78D99E926BD275EBB12E0A78DDDF", email="yizhong.wyz@alibaba-inc.com"):
        self.aid = aid
        self.token = token
        self.email = email

    def _build_data(self, **params):
        data = {}
        for key in params:
            data[key] = params[key]
        return data
    
    def _build_url(self, key, **params):
        data = {
            "aid": self.aid,
            "email": self.email,
            "token": self.token,
            "timestamp": int(time.time())
        }
        for k in params:
            data[k] = params[k]
        url = "http://jueying.sm.cn/api.php?do={}&{}".format(key, urllib.urlencode(data))
        log.info(url)
        return url

    def update(self, data={}, id=""):
        """
        修改数据接口
        """
        url = self._build_url("update", id=id, data=json.dumps(data))
        log.info(url)
        try:
            r = requests.get(url, timeout=10)
            log.info(r.text)
        except Exception as e:
            log.error(str(e))
            return False
        return True

    def delete(self, id=""):
        """
        删除数据接口
        """
        url = self._build_url("del", id=id)
        try:
            r = requests.get(url, timeout=10)
            log.info(r.text)
        except Exception as e:
            log.error(str(e))
            return False
        return True
     
    def publish(self):
        """
        发布接口
        """
        url = self._build_url("publish")
        log.info(url)
        try:
            r = requests.get(url, timeout=10)
            result = r.json()
            if not result.has_key("data"):
                return False
        except Exception as e:
            log.error(str(e))
            return False
        return True
        
    def select(self, data={}):
        """
        查询接口
        """
        log.info(data)
        url = self._build_url("select", search=json.dumps(data))
        log.info(url)
        res = None
        try:
            r = requests.get(url, timeout=10)
            result = r.json()
            log.info("test")
            log.info(json.dumps(result))
            res = result.get("data").get("data")
            if result.get("errorCode") != 0:
                log.error("select fail")
                return False, None
        except Exception as e:
            log.error(str(e))
            return False, None
        return True, res

    def update_from_frontend(self, id, cookie, **params):
        """
        从绝影前端模拟修改操作
        """
        if cookie == "":
            cookie = "l=AikpBmggARbh-PyGoUvM3OwCuc6K8x2o; cna=tmA8EUrMHh0CAXkAHe5h3AT6; sm_diu=4cf125f4c6fad41c30b4026e3736063d%7C%7C11eef1ee4b03299bd6%7C1511143562; jueyingSid=44990a4610b99f31a3a7846d0fff0daa; isg=AktLnqwrlSD2KsnGs2nIi4QX2u8r1z5LsvXMw71IRgrq3Go-RLLcs_I0wurJ; PHPSESSID=j0h2spe0c1u88hi52dufam4qm7"
        url = "http://jueying.sm.cn/content/entry.php?aid=%s&do=update&id=%s" % (self.aid, id)
        log.info(url)
        post_data = {}
        for key in params:
            post_data["data[%s]" % key] = params[key]
        post_data["id"] = id
        log.info(json.dumps(post_data))
        try:

            data = urllib.urlencode(post_data)
            log.info(data)
            headers = {"Cookie": cookie}
            r = requests.post(url, data=post_data, headers=headers)
            result = r.json()
            log.info(json.dumps(result))
            if result.get("data") not in ["true", "True", True] or  int(result.get("id")) != int(id):
                return False
        except Exception as e:
            log.error(e)
            return False
        return True



       
if __name__ == "__main__":
    #obj = JueYingWrapper(aid="677", token='38BE78D99E926BD275EBB12E0A78DDDF')
    obj = JueYingWrapper()
    #obj = JueYingWrapper(aid=677, token='EA5DAC1905333A30479FB6F9245AD0EB')
    #data = {"query": "wyztestkkkk"}
    #obj.update(data=data, id=1990)
    #obj.delete(id="1989")
    #obj.publish()
    #data = {"id": "1780"}
    #flag, res = obj.select(data=data)
    #log.info(json.dumps(res))
    #print obj.update_from_frontend(1780, "", type=9, question="上上下下左左右右BA", answer="恭喜你解锁彩蛋。", status=2)
    


