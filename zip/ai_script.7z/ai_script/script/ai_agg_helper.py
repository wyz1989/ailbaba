#!/usr/bin/python
#-*- encoding:utf8 -*-

import json
import copy
import tlib.log as log
import tlib.xpath as xpath


BODY_TPL = {
    "rewrite_query": "\u5f90\u9e64\u6797\\u00021\\u0001\u5f90\u9e64\u6797\\u00021", 
    "app_id": "8b051b94-9604-11e7-918e-90e2bac40398", 
    "session_id": "cce75c96dbbb11e7a68b90e2bac72cd4", 
    "common_params": [
        {
            "value": "8b051b94-9604-11e7-918e-90e2bac40398", 
            "key": "app_id"
        }, 
        {
            "value": "\u5f90\u9e64\u6797\u662f\u8c01", 
            "key": "query"
        }, 
        {
            "value": "", 
            "key": "query_id"
        }, 
        {
            "value": "test", 
            "key": "query_type"
        }, 
        {
            "value": "cce75c96dbbb11e7a68b90e2bac72cd4", 
            "key": "session_id"
        }, 
        {
            "value": "ae564102bf9c17215fdcada65b942eb37e0f50c9", 
            "key": "token"
        }, 
        {
            "value": "aliai", 
            "key": "vendor"
        }
    ], 
    "query": "\u5f90\u9e64\u6797\u662f\u8c01", 
    "requests": [
        {
            "exec_name": "sys.baike.SEARCH", 
            "req_params": [
                {
                    "value": "\u5f90\u9e64\u6797", 
                    "key": "baike_entity"
                }, 
                {
                    "value": "\u5f90\u9e64\u6797\u662f\u8c01", 
                    "key": "query"
                }
            ], 
            "type": "skill", 
            "id": 0, 
            "skill_name": "sys.baike"
        }, 
        {
            "exec_name": "sys.other", 
            "req_params": [
                {
                    "value": "\u5f90\u9e64\u6797\u662f\u8c01", 
                    "key": "query"
                }
            ], 
            "type": "skill", 
            "id": 1, 
            "skill_name": "sys.other"
        }
    ]
}

def build_ai_agg_body(sds_gw_result, token="", vendor="sm_test", query_type="test", session_id="", app_id=""):
    """
    由sds_gateway 构造ai_agg请求串的body
    """
    global BODY_TPL
    log.info(type(sds_gw_result))
    body = copy.copy(BODY_TPL)
    if sds_gw_result is None:
        return None
    try:
        intent_name = xpath.xpath_get(sds_gw_result, "/intent/intent_name")
        query = xpath.xpath_get(sds_gw_result, "/intent/query")
        skill_name = xpath.xpath_get(sds_gw_result,  "/intent/skill_name")
        if xpath.xpath_has(sds_gw_result, "/intent/slots"):
            slots = xpath.xpath_get(sds_gw_result, "/intent/slots")
        else:
            slots = []
        ### basic update
        body.update({"app_id": app_id, "query": query, "rewrite_query": query, "session_id": session_id})  
        ### update common_params
        common_params = body.get("common_params")
        for i in range(len(common_params)):
            item = common_params[i]
            log.info(item)
            key = item.get("key")
            if key == "app_id":
                body["common_params"][i]["value"] = app_id
            elif key == "query":
                body["common_params"][i]["value"] = query
            elif key == "session_id":
                body["common_params"][i]["value"] = session_id
            elif key == "token":
                body["common_params"][i]["value"] = token
            elif key == "vendor":
                body["common_params"][i]["value"] = vendor
        #### requests update
        tpl = {
                "exec_name": "%s.%s" % (skill_name, intent_name),
                "id": 0,
                "req_params": [],
                "skill_name": skill_name,
                "type": "skill"
        }
        tmp = copy.copy(tpl)
        if slots == []:
            #tmp["req_params"].append({"key": "query", "value": query})
            pass
        else:
            for slot in slots:
                name = slot.get("name")
                value = slot.get("value")
                if name == "intent":
                    continue
                tmp["req_params"].append({"key": name, "value": value})
        tmp["req_params"].append({"key": "query", "value": query})
        body["requests"] = [tmp]
    except Exception as e:
        log.error(str)
        return None
    return body
    

if __name__ == "__main__":
    sds_gw_result = {"action":[{"context":{"baike_entity":"周杰伦"},"data":[{"background_color":"7371bc,6764af,7f7dc6,6764af,ffffff","description":"周杰伦（Jay Chou），1979年1月18日出生于台湾新北市，华语流行男歌手、词曲创作人、制作人、演员、MV及电影导演、编剧及监制。2000年发行首张专辑《Jay》。2003年成为美国《时代周刊》亚洲版封面人物。凭借专辑《Jay》、《范特西》、《叶惠美》及《跨时代》四次获金曲奖最佳国语专辑奖，并凭借《魔杰座》、《跨时代》两度获金曲奖“最佳国语男歌手”奖。2014年、2015年两度获QQ音乐年度盛典最佳全能艺人奖。2015年获全球华语榜中榜亚洲影响力最受欢迎全能艺人奖。2005年以电影《头文字D》获台湾电影金马奖及香港电影金像奖“最佳新演员”奖。2007年成立杰威尔音乐有限公司，自编自导自演的电影《不能说的秘密》获台湾电影金马奖台湾年度杰出电影奖。2009年入选美国CNN亚洲极具影响力人物，2011年主演好莱坞电影《青蜂侠》进军国际，获美国MTV电影大奖最佳新人奖提名。2012年登福布斯中国名人榜榜首。2013年自编自导自演电影《天台爱情》获选美国纽约电影节闭幕片。除了从事自己的事业，周杰伦热心慈善，多次向内地灾区捐款并募款新建希望小学。","from":"people_star","general_attributes":[],"guid":"c641f28a-4724-11e5-8fdc-f80f41fb03aa","image_org":"http://s2.zimgs.cn/ims?kt=MD5&at=smk&key=826AD53C8BC8941D0009EF1224638927&tv=0_0&x.jpg","image_small":"http://s2.zimgs.cn/ims?kt=MD5&at=smk&key=826AD53C8BC8941D0009EF1224638927&tv=150_150_area&area=0,0,1,0.754&x.jpg","name":"周杰伦","ntype":"华语乐坛原创流行天王","openapi_name":"baike","url":"http://kb.kkyuyin.com/item/e17ccb61e6093c75d28f885a803dcbb6.html"}],"name":"baike_inform","skill_name":"sys.baike","speech":"周杰伦（Jay Chou），1979年1月18日出生于台湾新北市，华语流行男歌手、词曲创作人、制作人、演员、MV及电影导演、编剧及监制。2000年发行首张专辑《Jay》。2003年成为美国《时代周刊》亚洲版封面人物。凭借专辑《Jay》、《范特西》、《叶惠美》及《跨时代》四次获金曲奖最佳国语专辑奖，并凭借《魔杰座》、《跨时代》两度获金曲奖“最佳国语男歌手”奖。2014年、2015年两度获QQ音乐年度盛典最佳全能艺人奖。2015年获全球华语榜中榜亚洲影响力最受欢迎全能艺人奖。2005年以电影《头文字D》获台湾电影金马奖及香港电影金像奖“最佳新演员”奖。2007年成立杰威尔音乐有限公司，自编自导自演的电影《不能说的秘密》获台湾电影金马奖台湾年度杰出电影奖。2009年入选美国CNN亚洲极具影响力人物，2011年主演好莱坞电影《青蜂侠》进军国际，获美国MTV电影大奖最佳新人奖提名。2012年登福布斯中国名人榜榜首。2013年自编自导自演电影《天台爱情》获选美国纽约电影节闭幕片。除了从事自己的事业，周杰伦热心慈善，多次向内地灾区捐款并募款新建希望小学。","type":"inform_nlg"}],"intent":{"intent_name":"SEARCH","query":"周杰伦是谁","skill_name":"sys.baike","slots":[{"name":"baike_entity","value":"周杰伦"},{"name":"intent","value":"SEARCH"}]},"status":{"code":200,"message":""}}
    body = build_ai_agg_body(sds_gw_result, token="ae564102bf9c17215fdcada65b942eb37e0f50c9", app_id="8b051b94-9604-11e7-918e-90e2bac40398", session_id="xxxxx")
    log.info(json.dumps(body))



