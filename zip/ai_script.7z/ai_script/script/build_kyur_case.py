#!/usr/bin/python
#encoding:utf8


import re
import json

import tlib.log as log
import xpath2openapi

def parser_card_file(file_name="query1"):
    f = open(file_name, "r")
    lines = f.readlines()
    for line in lines:
        try:
            temp_list = line.strip("\n").split(",")
            querys = []
            query = ""
            sc_name = ""
            sc_stype = ""
            if len(temp_list) < 4:
                continue
            elif len(temp_list) == 4:
                query = temp_list[2]
            else:
                query = ",".join(temp_list[2:-1])
            sc_name = temp_list[0].strip()
            sc_stype = temp_list[1].strip()
            if sc_name == "":
                continue
            if sc_stype != "":
                sc_name = "%s|%s" % (sc_name, sc_stype)
            query = query.strip('"').strip("'")
            query = re.sub(r"\s*，\s*", ",", query)
            query = re.sub(r"\s*,\s*", ",", query)
            querys = query.split(",")
            log.info("%s=====>%s" % (sc_name,json.dumps(querys, ensure_ascii=False))) 
            xpath2openapi.build_xcase(sc_name, querys)
        except Exception as e:
            log.error(e)
            continue
    f.close()

parser_card_file()
