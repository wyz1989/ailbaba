#!/usr/bin/python
#encoding:utf-8

'''
@desc: 智能化全量query预处理
@author: yizhong.wyz
@date: 2018-02-27
'''

import json

import tlib.log as log
import tlib.auto as auto


def parse_line(line):
    '''返回5元组（query, skill, speech, status_code, app_id)
    '''
    if line is None or line == '':
        return []
    return line.split("`")


def cpfile_from_panggu():
    cmd = '/apsara/deploy/pu cp  pangu://AY-Shenma-SJL/zy/dump_query/all_query/1 .'
    status = auto.run(cmd).status
    if status != 0:
        raise Exception("exec cmd:[%s] fail" % cmd)


def save_file(data):
    """
    """
    file_name = "/apsarapangu/disk1/xonline_runtime/wm102530/ai/query/all_query_new.txt"
    with open(file_name, "w") as f:
        f.write(json.dumps(data))


def expend_data(result, key, data):
    """
    """
    if not result.has_key(key):
        result[key] = []
    result[key].append(data)


def preprocess():
    '''预处理函数
    '''
    #cpfile_from_panggu()
    result = []
    filters = {"511": "result_filter", "512": "query_filter", "510": "internal_error", "520": "ai_agg_fail", "500": "500", "400": "400"}
    with open("./1", "r") as f:
        lines = f.readlines()
        for line in lines:
            line = line.strip().strip("\n")
            tmp_list = parse_line(line)
            if len(tmp_list) != 5:
                tmp_list = None
                continue
            result.append(tmp_list) 
            """
            query, skill, status_code = tmp_list[0], tmp_list[1], tmp_list[3]
            if query == "":
                continue
            if skill == "":
                if status_code == "200":
                    continue
                if filters.get(status_code) is not None:
                    expend_data(result, filters.get(status_code), tmp_list)
                else:
                    log.info("status_code:%s" % status_code)
                    continue
            else:
                expend_data(result, skill, tmp_list)
            """
            tmp_list = None 
    save_file(result)


if __name__ == "__main__":
    preprocess()
