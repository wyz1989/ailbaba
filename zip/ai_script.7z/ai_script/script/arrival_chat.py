#!/usr/bin/python
#-*- encoding:utf8 -*-
"""
@author: yizhong.wyz
@desc: 闲聊数据插入索引和删除操作
"""

import requests
import json


import tlib.log as log

def build_data(query_key, query):
    """
        
    """
    data = {
        "records":{
            query_key:{
                "pk": query_key,
                "query": query,
                "answer": query,
                "chat_id": "30003443"
                }
            }        
    }
    return data


def chat_add(query_key, query, target="11.251.178.3:9091"):
    """
    增加闲聊数据到索引
    """
    data = build_data(query_key, query)
    url = "http://{}/?app=arrival&action=add".format(target)
    try:
        r = requests.post(url, data=json.dumps(data), timeout=10)
        result = r.json()
        if result.get("result") != "success":
            return False
    except Exception as e:
        log.error(str(e))
        return False

    return True


def chat_delete(query_key, query, target="11.251.178.3:9091"):
    """
    从索引中删除闲聊数据
    """
    data = build_data(query_key, query)
    url = "http://{}/?app=arrival&action=delete".format(target)
    try:
        r = requests.post(url, data=json.dumps(data), timeout=10)
        result = r.json()
        if result.get("result") != "success":
            return False
    except Exception as e:
        log.error(str(e))
        return False
    return True

    


if __name__ == "__main__":
    #chat_add("1000000", "我是一个测试")
    chat_delete("1000000", "我是一个测试")
