#!/usr/bin/python
#-*- encoding:utf8 -*-
"""
@desc:每日top query
@date: 2017-11-23
"""

import json
import datetime
import time

import tlib.log as log
from requestHelper import RequestHelper



def get_top_query(report_id=2157, is_not_trigger=0):
    """
    top query 获取
    """
    now = datetime.datetime.now()
    #end_time = now.strftime("%Y%m%d%H") 
    #log.info(end_time)
    delt = datetime.timedelta(days=-1)
    start_time = (now + delt).strftime("%Y%m%d%H")
    log.info(start_time)
    obj = RequestHelper()
    dim_filter = json.dumps([])
    if is_not_trigger:
        select_dims = ["query", "pv"]
    else:
        select_dims=["skill", "query"]
    data = []
    max_nums = 10000
    limit_start = 0
    step = 1000
    while 1:
        time.sleep(1)
        if limit_start >= max_nums:
            break
        obj.set_post_data(report_id, start_time=start_time, end_time=start_time, dim_filter=dim_filter, select_dims=select_dims, limit_start=limit_start, length=step)
        flag, result = obj.do_check()
        if not flag or len(result) == 0:
            log.error("get_query_fail")
            break
        else:
            data.extend(result.get("data"))
        limit_start += step
    querys = []
    [querys.append(x[1:]) for x in data]
    return querys

def save_query(querys, is_not_trigger=0):
    pre = datetime.datetime.now().strftime("%Y-%m-%d") 
    _path = "/apsarapangu/disk1/xonline_runtime/wm102530/ai/query/arrival/skill_query/"
    if is_not_trigger:
        file_name = "%s%s-topquery-not_trigger" % (_path, pre)
    else:
        file_name = "%s%s-topquery" % (_path, pre) 
    with open(file_name, "w") as f:
        f.write(json.dumps(querys, indent=4))

if __name__ == "__main__":
    querys = get_top_query()
    if querys:
        save_query(querys)
    querys = get_top_query(report_id=2324, is_not_trigger=1)
    log.info(json.dumps(querys, indent=4))
    if querys:
        save_query(querys, is_not_trigger=1)



    
