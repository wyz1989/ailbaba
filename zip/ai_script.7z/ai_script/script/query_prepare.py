#!/usr/bin/python
#encoding:utf8 
import json
import datetime
import uuid
import requests
import urllib

import tlib.log as log
import tlib.auto as auto



'''
@author: yizhong.wyz
@date: 2018/01/17
@desc: 压测query准备， 每天从Log中抽取关键业务方的query， 用于diff回归和全链路压测
'''

def get_daily_query():
    '''获取daily query'''
    daily_url = "http://wm102530.proxy.taobao.org/wm102530/ai/query/arrival/skill_query/daily/"
    day = datetime.datetime.now().strftime("%Y-%m-%d")
    try:
        r = requests.get("%s%s_success.txt" % (daily_url, day), timeout=10)
        if r is not None and len(r.json()) != 0:
            return r.json()
        else:
            raise Exception("empty query ")
    except Exception as e:
        log.error("get day:%s query fail" % day)
        delt = datetime.timedelta(days=-1)
        now = datetime.datetime.now()
        day = (now + delt).strftime("%Y-%m-%d")
        log.info(day)
        try:
            r = requests.get("%s%s_success.txt" % (daily_url, day), timeout=10)
            if r is not None:
                return r.json()
        except Exception as e:
            log.error(e)
            return []
    return []

def construct_press_query(querys):
    '''
    构造压测query
    '''
    app_ids = [
                "cd9fec76-e60a-11e7-9865-6c92bf324856", 
                "9a6428f6-9d10-11e7-95f9-6c92bf29f312",
                "88f118fa-bf97-11e7-aebf-6c92bf29f598",
                "476c0f42-c3b2-11e7-b4ba-6c92bf29f312",
                "17cc3354-caae-11e7-9579-6c92bf29f312",
                "7061be9e-ca9f-11e7-8de5-6c92bf29f598",
                "0ebe2e7a-9c1e-11e7-8086-6c92bf29f598",
                "8b051b94-9604-11e7-918e-90e2bac40398",
                "70a0bca4-9ce4-11e7-9fd9-6c92bf29f312",
                "14f30502-b2eb-11e7-9a4d-6c92bf29f312"
              ]
    save_file = "/apsarapangu/disk1/xonline_runtime/wm102530/ai/query/arrival/press_query/diff.query"
    f = open(save_file, "w")
    for query in querys:
        try:
            session_id = str(uuid.uuid1()).replace("-", "")
            q = query.get("query").encode("utf8")
            app_id = query.get("app_id")
            if app_id not in app_ids:
                continue
            url = "/query?session_id=%s&query=%s&app_id=%s&token=3ce0cd89497a368098e62cf9a21f1004dec168d0" % (session_id, urllib.quote(q), app_id) 
            f.write("%s\n" % url)
        except Exception as e:
            log.error(e)
            continue
    f.close()

querys = get_daily_query()
log.info(len(querys))
if len(querys) != 0:
    construct_press_query(querys)

    auto.run("/apsara/deploy/pu cp -m overwritten /apsarapangu/disk1/xonline_runtime/wm102530/ai/query/arrival/press_query/diff.query  pangu://AY501/home/fangshu.cfs/yizhong_arrival/diff.query")
else:
    log.info("please check data")
        
        

