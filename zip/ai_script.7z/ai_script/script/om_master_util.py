#!/usr/bin/python
#-*- encoding:utf8 -*-
"""
@author: yizhong.wyz
@date: 2018-03-26
@desc: 核心库数据获取脚本
"""
import requests
import json

import tlib.log as log


def build_params(module="maq", om_master_target="11.180.55.102:3268"):
    """
    return:
    @url
    @post_data
    """
    url = "http://{}/{}/read".format(om_master_target, module)
    log.info(url)
    post_data = {
        "user_id": "",
        "token": "",
        "condition":{"state": 1},
        "begin": 0,
        "end": 10,
        "order_field": "",
        "order_type": "desc",
        "type": "fuzzy"
    }
    return url, post_data


def filter_result(data):
    data_list = []
    for item in data:
        data_list.append({"id": item.get("id"), "type": item.get("type"), "question": item.get("question"), "answer": item.get("answer"), "status": item.get("state")})
    return data_list


def get_data(module_name, step=1000, total=0, om_master_target="11.180.55.102:3268"):
    list_key = ""
    if module_name == "makeup":
        url, post_data = build_params(module="makeup", om_master_target=om_master_target)
        list_key = "makeups"
    elif module_name == "filter":
        url, post_data = build_params(module="filter", om_master_target=om_master_target)
        list_key = "filters"
    elif module_name == 'chat':
        url, post_data = build_params(module="chat", om_master_target=om_master_target)
        list_key = "chats"
    elif module_name == "maq" or module_name == "kernel":
        url, post_data = build_params(module="maq", om_master_target=om_master_target)
        list_key = "maqs"
    begin = 0
    end = 0 
    lists = []
    while 1:
        if total and end >= total:
            break
        end += step
        post_data["begin"] = begin
        post_data["end"] = end
        try:
            r = requests.post(url, data=json.dumps(post_data), timeout=10)
            if r.json().get("status") != 0:
                log.info("get data fail")
                return lists
            temp_list = r.json().get(list_key)
            if temp_list is None or  len(temp_list) == 0:
                log.info("get query has end")
                break
            lists.extend(temp_list)
            log.info(len(lists))
        except Exception as e:
            log.error(str(e))
            break
        begin += step
    return filter_result(lists)

if __name__ == "__main__":
    data = get_data("maq", total=1000)
    log.info(len(data))
    log.info(json.dumps(data[0], indent=4))
