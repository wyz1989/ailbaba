#!/usr/bin/python
#encoding:utf8

"""
@author: yihzong.wyz
@date: 2018-04-10
@desc: 将openapi配置的xpath路径映射为智能化统一输出协议格式，同时自动生成功能case
"""
import requests
import json
import re
import copy
import urllib

import tlib.log as log

TOKEN="3ce0cd89497a368098e62cf9a21f1004dec168d0"
APPID = "14f30502-b2eb-11e7-9a4d-6c92bf29f312"
URL_PARAMS="/query?filter_debug=1&query={query}&app_id={app_id}&token={token}&debug=1"
XCASE_TEMPLATE = {
            "querys":[],
            "level": 1
        }

def get_openapi_template(url="http://jueying.sm.cn/content/data/application_1027.json"):
    """
    openapi模板
    """
    r = requests.get(url, timeout=10)
    return r.json()


def adjust_template(template_data):
    result = {}
    for item in template_data:
        json_field_info_name = item.get("json_field_info_name")
        result[json_field_info_name] = item
    return result


def build_checklist(data):
    """
    @return
    check_list
    """
    check_list = []
    json_field_info = data.get("json_field_info")
    for item in json_field_info:
        try:
            names = re.split(r"\s*,\s*", item.get("name"))
            log.info(names)
            _type = item.get("type")
            field_name = item.get("field_name")
            pre = "/action/0/data/0"
            if _type == "attribute":
                pass
            elif _type == "object":
                pre = "%s/%s" % (pre, field_name)
            elif _type == "list":
                pre = "%s/%s/0" % (pre, field_name)
            else:
                continue
            for name in names:
                rule = []
                rule.append("%s/%s" % (pre, name))
                rule.append("has")
                check_list.append(rule)
        except Exception as e:
            log.error(e)
            continue
    return check_list         


def build_url_params(query):
    """
    build url_params
    """
    global URL_PARAMS,APPID,TOKEN
    url_params = URL_PARAMS
    return url_params.format(query=urllib.quote(query), token=TOKEN, app_id=APPID)


def build_xcase_data(template_data, sc_name, querys):
    """
    构造xcase
    """
    data = template_data.get(sc_name)
    if data is None:
        log.error("can not find %s from template" % sc_name)
        return None
    xcase_data = {
            "querys":[],
            "level": 1
        }
    check_list = build_checklist(data)
    for query in querys:
        try:
            url_params = build_url_params(query)
            xcase_data["querys"].append({"url_params": url_params, "check_list": check_list})
        except Exception as e:
            log.error(e)
            continue
    log.info(json.dumps(xcase_data, indent=4))
    return xcase_data


template_data = get_openapi_template()
template_data = adjust_template(template_data)

def build_xcase(sc_name, querys):
    """

    """
    global template_data
    file_name = "tc_%s" % sc_name.replace("|", "_")
    xcase_data = build_xcase_data(template_data, sc_name, querys)
    if xcase_data is None:
        return
    with open(file_name, "w") as f:
        f.write(json.dumps(xcase_data, indent=4))


if __name__ == "__main__":
    #sc_name = "general_entity_medicine|disease_other"
    """
    sc_name = "general_entity_architecture"
    template_data = get_openapi_template()
    template_data = adjust_template(template_data)
    build_xcase_data(template_data, sc_name, ["病症"])
    """
    build_xcase("general_entity_architecture", ["病症", "new"])

