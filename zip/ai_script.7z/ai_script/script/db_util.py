#!/usr/bin/python
#-*- encoding:utf8 -*-

"""
@desc: 数据库操作辅助函数
@author: wangyizhong
@date: 2017-11-21 
"""
import json
import copy


import tlib.log as log
from tlib.mysql_wrapper import MysqlWrapper


class DBUtil(MysqlWrapper):
    def __init(self, user, password, host, database, port=3306):
        MysqlWrapper.__init(user, password, host, database, port=port)

    def get_app_versions(self):
        cmd='select id,  version, last_modify_time from app_table where version !="" group by id;'
        app_infos = self.query(cmd)
        
        app_versions = {}
        for (id, version, last_modify_time) in app_infos:
            if id not in app_versions:
                app_versions[id] = [{"version": version, "last_modify_time": str(last_modify_time)}]
            else:
                app_versions[id].append({"version": version, "last_modify_time": str(last_modify_time)})
        app_ids = set([x[0] for x in app_infos])
        cmd = 'select app_id, skill_id, sys_skill_meta_table.name, app_skill_table.type  from app_skill_table, sys_skill_meta_table where app_id="%s" and skill_id=sys_skill_meta_table.id;'
        app_skills = {}
        for app_id in app_ids:
            temp_cmd = cmd % app_id
            ret = self.query(temp_cmd)
            app_skills[app_id] = []
            for (id, skill_id, skill_name, type) in ret:
                app_skills[app_id].append({"skill_id": skill_id, "skill_name": skill_name, "type": type})

        result = {
            "app_versions": app_versions,
            "app_skills": app_skills
        }
        return result

    def get_data_info(self, app_id, version, role='nlu'):
        """
            通过查询数据库，找到需要推送给nlu的数据
        """
        cmd = "select data_name, data_version, app_version, app_id, role, filepath from data_info_table where app_id='%s' and app_version='%s' and role='%s'" % (app_id, version, role)  
        log.info(cmd)
        data_infos = self.query(cmd)
        meta = {
            "app_id": "",
            "app_name": "",
            "app_version": "",
            "role": role,
            "data_name": "",
            "data_version": "",
            "filepath": "",
            "create_time": "",
            "last_modify_time": "",
            "checksum": "",
            "extension": ""
        } 
        log.info(json.dumps(data_infos))
        result_list = []
        keys = ["data_name", "data_version", "app_version", "app_id", "role", "filepath"]
        for data in data_infos:
            meta_tmp = copy.copy(meta)
            temp = dict(zip(keys, data))
            meta_tmp.update(temp)
            result_list.append(meta_tmp)
        return result_list
            
    def get_skills_by_appid(self, app_id='8b051b94-9604-11e7-918e-90e2bac40398', type="sys"):
        '''
        获取指定app_id的所有技能
        '''
        table = "sys_skill_meta_table" if type == "sys" else "user_skill_table"
        cmd = "select a.skill_id, a.skill_version, b.name, b.main_version from app_skill_table as a, %s as b  where app_id='%s' and b.id=a.skill_id;" % (table, app_id)
        log.info(cmd)
        data = self.query(cmd)
        skills = []
        for item in data:
            skills.append({"skill_id": item[0], "skill_name": item[2]})
        log.info(json.dumps(skills, indent=4)) 
        return skills

    def get_all_skills(self):
        """
        获取所有的技能列表
        """
        sql = 'select id, name, description,create_time,  scene_type from sys_skill_meta_table;'
        log.info(sql)
        data = self.query(sql)
        skills = []
        [skills.append({"id": x[0], "name": x[1], "description": x[2], "create_time": str(x[3])}) for x in data]
        log.info(json.dumps(skills))
        return skills


if __name__ == "__main__":
    obj =  DBUtil("arrival", "", "11.251.177.218", "arrival_nbest")  
    data = obj.get_all_skills()
    #obj.get_skills_by_appid()
    #result = obj.get_app_versions()
    #log.info(json.dumps(result, indent=4))
    #file = "/apsarapangu/disk1/xonline_runtime/wm102530/ai/query/arrival/app_info.txt"
    #with open(file, "w") as f:
        #f.write(json.dumps(result, indent=4))
    #result_list = obj.get_data_info("a4343e00-b572-11e7-8f8f-90e2bac72b60", "0.0.1")
    #log.info(json.dumps(result_list))
    
