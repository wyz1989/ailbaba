#!/usr/bin/python
#encoding:utf8
"""
@author: yizhong.wyz
@date: 2018-05-16
@desc: 内容结果diff和压测流程query集合准备
"""

import urllib
import json
import uuid
from random import shuffle

import tlib.log as log


spec_appids = [
	"db448026-4145-11e8-8120-90e2bac72b60",
	"8b051b94-9604-11e7-918e-90e2bac40398"
]

token = "3ce0cd89497a368098e62cf9a21f1004dec168d0"
TPL = "/query?session_id={}&query={}&app_id={}&token={}&vendor=sm_test"

fr = open("all_query_new.txt", "r")

result = json.loads(fr.read())
shuffle(result)

press_query = open("press_query", "w")
diff_query = open("diff.query", "w")
for line in result:
	try:
		if len(line) != 5:
			continue
		query = line[0]
		appid = line[4]
		session_id = str(uuid.uuid1()).replace("-", "")	
		press_query.write(TPL.format(session_id, urllib.quote(query.encode("utf8")),appid, token))
		press_query.write("\n")
		if appid in spec_appids:
			diff_query.write(TPL.format(session_id, urllib.quote(query.encode("utf8")), appid, token))
			diff_query.write("\n")
	except Exception as e:
		log.error(e)
		continue

