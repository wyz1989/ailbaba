#!/usr/bin/bash
### spl pb query extract



SAVE_FILE="/home/admin/online/disk1/xonline_runtime/spl_query"
let i=0
for FILE_NAME in `ls /home/admin/online/disk1/xonline_runtime/spl_log`
do
	if [[ ${FILE_NAME:0:14} = "specific_logic" ]];then
		cat /home/admin/online/disk1/xonline_runtime/spl_log/$FILE_NAME | grep  -Po '(pbstr\[.*\])' | grep -Po '\[.*\]' | sed -n 's/\[//p' | sed -n 's/\]//p' | awk '{print "/work##"$0}'>> $SAVE_FILE
		let i=i+1	
	fi
	echo $i
	if [[ $i -eq 2 ]];then
		break
	fi
done


#head -1 specific_logic.log.20180117003019-001 | grep  -Po '(pbstr\[.*\])' | grep -Po '\[.*\]' > query
