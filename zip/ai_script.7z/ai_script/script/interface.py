#!/usr/bin/python
#-*- encoding:utf8 -*-

"""
神降临后端接口封装
"""
import tlib.log as log
from db_util import DBUtil


import datetime
import json
import requests


def get_app_meta(app_name, **params):
    """
    build app_meta
    """
    data_tpl = {
            "name": app_name,
            "type": "",
            "id": "",
            "description": "",
            "create_time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "last_modify_time": "",
            "icon": ""
            }
    for key in params:
        if data_tpl.has_key(key):
            data_tpl[key] = params[key]
    return data_tpl
        
def get_app_skill(id="", name="", type="sys"):
    """
    app_skill 结构
    """
    return {
            "id": id,
            "name": name,
            "type": type,
            "changed": "",
            "state": -1
        }


def get_app_fallback(text=""):
    return {"text": text}


def read_skill(user_id="admin", token="", skill_id="", target="11.251.206.194:3222"):
    """
    通过接口获取用户技能信息
    """
    url = 'http://{}/skill/read'.format(target)
    log.info(url)
    data = {"user_id": user_id, "token": token, "skill_id": skill_id}
    log.info(json.dumps(data, indent=4))
    result = get_response(url,  data=data)
    log.info(json.dumps(result, indent=4))
    return result


def get_skill_info(type="sys", name="currency"):
    """
    type: 技能类型
    name: 技能名
    """
    db = DBUtil("arrival", "", "11.251.177.218", "arrival_nbest")
    if type == "sys":
        cmd = 'select id, name, main_version, description, create_time,  last_modify_time from sys_skill_meta_table where name="%s" limit 1' % name
    elif type == "user":
        cmd = 'select id, name, main_version, description, create_time,  last_modify_time from user_skill_table where name="%s" limit 1' % name
    log.info(cmd)
    skill_info = db.query(cmd)
    log.info(skill_info)
    keys = ["id", "name", "main_version", "description", "create_time", "last_modify_time"]
    _dict = dict(zip(keys, skill_info[0]))
    _dict["type"] = type
    _dict["create_time"] = str(_dict["create_time"]) 
    _dict["last_modify_time"] = str(_dict["last_modify_time"]) 
    log.info(json.dumps(_dict, indent=4))
    return _dict


def app_update(user_id="admin",token="", app_id="", meta=None, fallback=None, skill=None, target="11.251.206.194:3222", flag=0):
    """
    应用更新接口
    flag表示操作类型
    0 更新
    1 add
    -1 删除
    """
    data = read_app(app_id=app_id, user_id="admin", target=target)
    app_info = data.get("app")
    if fallback:
        app_info["fallback"] = fallback
    if meta:
        app_info["meta"] = meta
    if skill:
        if flag == 1:
            ### 新增技能
            app_info["skill"].extend(skill) 
        elif flag == -1:
            ### 删除技能
            tmp_skills = []
            for sk in app_info["skill"]:
                skill_id = sk.get("id")
                is_del = 0
                for s in skill:
                    if s.get("id") == skill_id:
                        is_del = 1
                        break
                if is_del:
                    continue
                tmp_skills.append(sk)
            app_info["skill"] = tmp_skills
        else:
            app_info["skill"] = skill
    if app_info.has_key("state"):
        app_info.pop("state")
    data ={
        "user_id": user_id,
        "token": token,
        "app": app_info
      }
    log.info(json.dumps(data, indent=4))
    url = "http://{}/app/update".format(target)
    result = get_response(url, data=data)
    log.info(json.dumps(result, indent=4))
    if result.get("status") != 0:
        return False
    return True


def get_response(url, data="", method="post", timeout=10, retry_times=3):
    """
    """
    i = 0
    r = None
    result = ""
    while i < retry_times:
        try:
            if method == "post":
                r = requests.post(url, data=json.dumps(data), timeout=timeout)
            elif method == "get":
                r = requests.get(url, timeout=timeout)
            if r is None:
                i += 1
                continue
            result = r.json()
            break
        except Exception as e:
            log.error(e)
            i += 1
            continue
    return result


def create_app(app_name="app_test", target="11.251.206.194:3222"):
    """
    创建app接口
    """
    url = "http://{}/app/create".format(target)
    user_id = "admin"
    token = ""
    meta = get_app_meta(app_name)
    data = {
        "user_id": user_id,
        "token": token,
        "app":{
            "meta": meta
            }
      }
    log.info(json.dumps(data, indent=4))
    result = get_response(url, data=data)
    log.info(json.dumps(result, indent=4))
    if result.get("status") != 0:
        return False, ""
    app_id = result.get("id")
    return True, app_id


def read_app(app_id="",  user_id="", token="", target="11.251.206.194:3222"):
    """
    查询app信息
    """
    url = "http://{}/app/read".format(target)
    data = {
        "user_id": user_id,
        "token": token,
        "app_id": app_id
    }
    result = get_response(url, data=data)
    log.info(json.dumps(result, indent=4))
    return result
    

def delete_app(app_id="", user_id="admin", token="", target="11.251.206.194:3222"):
    '''
    删除app
    '''
    data = {
        "app_id": app_id,
        "user_id": user_id,
        "token": token
    }
    url = 'http://{}/app/delete'.format(target) 
    result = get_response(url, data=data)
    log.info(json.dumps(result, indent=4))
    if result.get("status") != 0:
        return False
    return True

    
if __name__ == "__main__":
    #create_app()
    #read_app(user_id="admin", app_id="a41f908c-0ee0-11e8-a70a-90e2bac76394")
    #read_app(user_id="admin", app_id="ef4ee0ae-ebbc-11e7-b8d8-90e2bac76394")
    #read_skill(skill_id="16")
    #get_skill_info(name="baike")
    #app_update("86c64950-eae5-11e7-9e7e-90e2bac76394")
    skills = []
    skills.append(get_app_skill(id="40", name="高质量问答"))
    #skills.append(get_app_skill(id="17", name="baike"))
    app_update(app_id="a41f908c-0ee0-11e8-a70a-90e2bac76394", skill=skills, flag=-1) 
    read_app(user_id="admin", app_id="a41f908c-0ee0-11e8-a70a-90e2bac76394")
    #create_app()
    """
    skills = []
    skills.append(get_app_skill(id="40", name="高质量问答"))
    skills.append(get_app_skill(id="17", name="baike"))
    app_update(app_id="ef4ee0ae-ebbc-11e7-b8d8-90e2bac76394", skill=skills)
    read_app(user_id="admin", app_id="ef4ee0ae-ebbc-11e7-b8d8-90e2bac76394")
    """
    #delete_app(app_id="4cf1f420-ec4f-11e7-8951-90e2bac76394")
    #read_app(app_id="4d016a2c-ec4f-11e7-b8d8-90e2bac76394", user_id="admin")


    
