#!/usr/bin/python
#-*- encoding:utf8 -*-

"""
@desc: 总包语料处理
@author: wangyizhong
@date: 2017.11.30
"""
import json
import os

from tlib.path import home_path
import tlib.log as log
import tlib.svn as svn
import tlib.auto as auto
from tlib import name

skills =[
            "calendar",
            "currency",
            "express",
            "history",
            "lbs",
            "nba",
            "oil",
            "recipe",
            "timezone",
            "unit",
            "xianxing"
         ]
def init():
    """
    workspace init
    """
    case_name = name.get()
    workspace = home_path() / case_name
    log.info(workspace)
    workspace.makedirs()
    return workspace

def check_corpus_version():
    """
    check corpus version
    """
    svn_address = "http://svn.simba.taobao.com/svn/Apsara/galaxy/trunk2/shenma_online/arrival/cc/trunk/"
    log.info(json.dumps(svn.get_info(svn_address), indent=4))
    version = svn.get_info(svn_address)["revision"]
    log.info("version:%s" % version)
    need_update = False 
    if not os.path.exists("last_version"):
        need_update = True
        with open("last_version", "w") as f:
            f.write("%s\n" % version)
    else:
        fr = open("last_version", "r")
        last_version = fr.read().strip("\n")
        fr.close()
        log.info("last_version:%s" % last_version) 
        if last_version != version:
            need_update = True
            with open("last_version", "w") as f:
                f.write("%s\n" % version)
    return need_update 
        

def co(workspace):
    svn_address = "http://svn.simba.taobao.com/svn/Apsara/galaxy/trunk2/shenma_online/arrival/cc/trunk/"
    svn.co(svn_address, workspace / "svn")
    if not (workspace / "svn" / "script").exists():
        log.error("svn co is fail")
        raise Exception("svn co is fail")

def get_querys(file_path):
    querys = []
    lines = []
    with open(file_path, "r") as f:
        lines = f.readlines()
    for line in lines:
        try:
            line = line.strip().strip("\n")
            temp_list = line.split("\t")
            slot = ""
            if len(temp_list) < 4:
                continue
            elif len(temp_list) >= 5:
                slot = temp_list[4]
            querys.append({"skill_name": temp_list[0] , "intent": temp_list[1], "query": temp_list[3], "slot": slot, "type": temp_list[2]})
        except Exception as e:
            continue
    return querys

def do_handler(workspace):
    global skills
    pre_dir = "/apsarapangu/disk1/xonline_runtime/wm102530/ai/query/arrival/skill_query/train/"
    for skill in skills:
        file = "%s.txt" % skill
        if not (workspace / "svn" / "script" /skill / file).exists():
            log.error("file:%s not exists" % file)
            continue
        querys = get_querys(workspace / "svn" / "script" / skill/ file)
        save_file = pre_dir + "%s.txt" % skill
        with open(save_file, "w") as f:
            f.write(json.dumps(querys, indent=4))

def run():
    flag = check_corpus_version()
    if flag:
        log.info("need to update")
        workspace = init()
        co(workspace)
        do_handler(workspace)
        #workspace.rmdir() 
        auto.run("rm -rf %s" % workspace)
    log.info("success")

if __name__ == "__main__":
    run()
