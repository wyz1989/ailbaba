#!/usr/bin/python
import daily_query_preprocessing
import process_new

from tlib.xapi import XReportAPI

obj = XReportAPI()
daily_query_preprocessing.preprocess()
all_query = "/apsarapangu/disk1/xonline_runtime/wm102530/ai/query/all_query.txt"
obj.save_path("wyz", all_query)

process_new.preprocess()
all_query_new = "/apsarapangu/disk1/xonline_runtime/wm102530/ai/query/all_query_new.txt"
obj.save_path("wyz", all_query_new)
