#!/usr/bin/python
#encoding:utf8

import os
import uuid
import requests
import json
import urllib

import tlib.log as log

def press_query():
    """
    构造压测query
    """
    file_name = "/apsarapangu/disk1/xonline_runtime/wm102530/ai/query/all_query.txt"
    if os.path.exists(file_name):
        f = open(file_name, "r")
        result = json.loads(f.read().strip("\n"))
        f.close()
    else:
        try:
            r = requests.get("http://xreport.alibaba-inc.com/wyz/all_query.txt", timeout=10) 
            result = r.json()
        except Exception as e:
            log.error(e)
            raise e
    lines = [] 
    for skill, lists in result.items():
        for _list in lists:
            try:
                query, appid = _list[0], _list[4]
                session_id = str(uuid.uuid1()).replace('-', '')
                url = "/query?session_id={session_id}&query={query}&app_id={app_id}&token=3ce0cd89497a368098e62cf9a21f1004dec168d0".format(session_id=session_id, query=urllib.quote(query.encode("utf8")), app_id=appid.encode("utf8"))
                lines.append(url)
            except Exception as e:
                log.error(e)
                continue

    savefile = "/apsarapangu/disk1/xonline_runtime/wm102530/ai/query/press_query"
    f = open(savefile, "w")
    for line in lines:
        try:
            f.write("%s\n" % line) 
        except Exception as e:
            log.error(e)
            continue
        
    from tlib.xapi import XReportAPI
    obj = XReportAPI()
    obj.save_file(group_name="wyz", localfile=savefile)
    

press_query()
