#!/usr/bin/python
#-*- encoding:utf8 -*-
"""
@date: 2017/08/15
@author: yizhong.wyz
@desc: 获取ark平台数据
"""

import tlib.log as log

import requests
import json


class RequestHelper():
    """
        速读平台接口请求封装
    """
    def __init__(self):
        self._access_key = "Yz4xtwTOG&E0It#0"
        self._username = "yizhong.wyz"
        self._password = "wyz@sm123"
        self.length = 1000
        self.postdata = {}
        self.base_url = "http://shudu.sm.cn/statistic/feature_api/%s/"
        self.url = ""
    
    def set_post_data(self, report_id, **params):
        self.postdata = {}
        self.url = self.base_url % str(report_id)
        log.info("url=[%s]" % self.url)  
        self.postdata["access_key"] = self._access_key
        self.postdata["username"] = self._username
        self.postdata["password"] = self._password
        self.postdata["length"] = self.length
        for k, v in params.items():
            if k == "select_dims":
                self.postdata["select_dims[]"] = v 
            else:
                self.postdata[k] = v

    def do_check(self):
        result = None
        try:
            log.info(json.dumps(self.postdata))
            req = requests.post(self.url, data=self.postdata, timeout=10)
            if req is None:
                return False, ""
            result = req.json()
            if result.get("status") is None or result.get("status") != 0:
                return False, ""
        except Exception as e:
            log.error(str(e))
        return True, result

if __name__ == "__main__":
    obj = RequestHelper()
    #dim_filter = json.dumps([["qudao", "eq", "全部"]])
    dim_filter=json.dumps([])
    select_dims=["skill", "query"]
    #select_dims = []
    obj.set_post_data(2157, start_time="2017112217", end_time="2017112217", dim_filter=dim_filter, select_dims=select_dims)
    flag, result = obj.do_check()
    log.info(json.dumps(result))
