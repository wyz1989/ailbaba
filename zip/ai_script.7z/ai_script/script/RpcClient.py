#!/usr/bin/python
#encoding:utf8

"""
@author: yizhong.wyz
@desc: RPC调用
"""
import xmlrpclib
import sys

import tlib.log as log
import tlib.remotefile as remotefile


class RpcClient(object):
    def __init__(self, rpc_ip="xreportrpc.alibaba-inc.com", rpc_port="80"):
        self.rpc_ip = rpc_ip
        self.rpc_port = rpc_port
        self.proxy = xmlrpclib.ServerProxy("http://{}:{}/".format(self.rpc_ip, self.rpc_port))

    def save_dir(self, group_name="", localdir=""):
        try:
            remotefile.upload("xreport/{}".format(group_name), localdir) 
            return self.proxy.save_report("1", group_name, "", "", localdir)
        except Exception as e:
            log.error(str(e))
            return False, str(e), ""
            
    def save_file(self, group_name="", localfile=""):
        try:
            remotefile.upload("xreport/{}".format(group_name), localfile) 
            return self.proxy.save_report("1", group_name, "", "", localfile)
        except Exception as e:
            log.error(str(e))
            return False, str(e), ""

    def save_content(self, group_name="", report_name="", content=""):
        return self.proxy.save_report("0", group_name, report_name, content, "")


if __name__ == "__main__":
    obj = RpcClient()
    #flag, msg, url = obj.save_content(group_name="wyz", report_name="kkk.html", content="kdkdkdkdkdk")
    #flag, msg, url = obj.save_dir(group_name="wyz", localdir="./mytest")
    flag, msg, url = obj.save_file(group_name="wyz1", localfile="ai_agg_helper.py")
    log.info(url)
