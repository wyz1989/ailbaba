#!/usr/bin/python
#encoding:utf8

import threading
import json
import uuid
import sys
import time
import requests
from random import shuffle

import tlib.log as log
import tlib.xpath as xpath
from tlib.check import check
from tlib.check import base_check
from tlib.check import CheckError

mutex = threading.Lock()
execpt_num = 0
result = []

class WorkThread(threading.Thread):
    def __init__(self, threadid, query_lists):
        threading.Thread.__init__(self)
        self.threadid = threadid
        self.query_lists = query_lists
        log.info(len(query_lists))
        self.fail_querys = []
        self.check_list = [
                ["/status/code","==",200],
                ["/intent/skill_name", "==", "sys.stock"],
                ["/action/0/speech", "len>", 0]
                ]
    
    def get_url(self, query, target='arrival.sm.cn', app_id='70a0bca4-9ce4-11e7-9fd9-6c92bf29f312'):
        session_id = str(uuid.uuid1()).replace('-', '')
        url = 'http://{}/query?query={}&app_id={}&session_id={}&token={}'.format(target, query, app_id, session_id, "3ce0cd89497a368098e62cf9a21f1004dec168d0")
        return url

    def run(self):
        global result, execpt_num
        for query in self.query_lists:
            try:
                time.sleep(0.02)
                query = query.strip().strip("\n")
                url = self.get_url(query)
                r = requests.get(url, timeout=10)
                response = r.json()
                speech = ""
                speech = xpath.xpath_get(response, "/action/0/speech")
                try:
                    for i in self.check_list:
                        check(response, *map(lambda x: globals()[x] if isinstance(x, (str, unicode)) and x.startswith("_check_") else x, i))
                except:
                    self.fail_querys.append({"query": query, "url": url, "speech": speech.encode("utf8")})
            except Exception as e:
                log.error(str(e))
                if mutex.acquire(2):
                    execpt_num += 1
                    mutex.release()
                continue
        if mutex.acquire(2):
            result.extend(self.fail_querys)
            log.info("append result success")
            mutex.release()


def begin():
    """
    """
    if len(sys.argv) != 4:
        log.info("usage: ./pultiprocess.py totalnum threadnum save_file")
        sys.exit(1)
    totalnum = int(sys.argv[1])
    log.info(totalnum)
    threadnum = int(sys.argv[2])
    save_file = sys.argv[3]
    query_file = "/apsarapangu/disk1/xonline_runtime/wm102530/ai/query/stock.raw"
    lines = []
    with open(query_file, "r") as f:
        lines = f.readlines()
    shuffle(lines)
    lines = lines[:totalnum]
    totalnum = len(lines)
    log.info(totalnum)
    query_sig = totalnum / threadnum
    thread_lists = []
    if query_sig == 0:
        thread = WorkThread("0", lines)
        thread_lists.append(thread)
    else:
        for i in range(threadnum - 1):
            tmp_query_list = lines[i*query_sig: (i+1)*query_sig]
            thread_lists.append(WorkThread(str(i), tmp_query_list))
        thread_lists.append(WorkThread(str(i+1), lines[(i+1)*query_sig:]))
    for thread in thread_lists:
        thread.start()

    for thread in thread_lists:
        thread.join()
    global result
    global execpt_num
    totalnum -= execpt_num
    with open(save_file, "w") as f:
        f.write(json.dumps(result))
    with open("%s_simple" % save_file, "w") as f:
        f.write("total:%s  fail:%s ratio:%s\n" % (totalnum, len(result), float(len(result))/ totalnum))
        f.write("query|speech\n")
        for item in result:
            f.write("%s|%s\n" % (item.get("query"), item.get("speech") if item.get("speech") is not None and item.get("speech") !=""  else ""))

begin()
    
