#!/usr/bin/python
#-*- encoding:utf8 -*-
"""
@author: yizhong.wyz
@date: 2018-03-21 
@desc：远程调用(RPC)服务端实现
"""

from SimpleXMLRPCServer import SimpleXMLRPCServer
import sys
import os

import tlib.log as log
import tlib.auto as auto
import tlib.remotefile as remotefile


class RpcServer(object):
    def __init__(self, folder="", domain=""):
        self.folder = folder.rstrip("/")
        self.domain = domain.rstrip("/")

    def save_report(self, is_path, group_name, report_name, content, dir_name):
        """
            存储报告
            @is_path [0|1] 1表示将目录或者是文件上传到静态服务器, 0表示直接将内容写入到静态服务器
            return:
            @msg 信息
            @flag 状态
            @url url地址
        """
        if int(is_path):
            return self._push_dir(group_name, dir_name)
        else:
           return self._push_file(group_name, report_name, content)

    def _check_group(self, group_name):
        """
            查看本地group文件夹是否存在，不存在则创建
        """
        group_dir = "{}/{}".format(self.folder, group_name)
        if not os.path.exists(group_dir):
            log.info("%s not exists, so create it" % group_dir)
            status = auto.run("mkdir -p {}".format(group_dir)).status
            if status != 0:
                raise Exception("mkdir -p %s , fail" % group_dir)
        return group_dir

    def _push_file(self, group_name, report_name, content):
        """
            文件存储
            @group_name 分组名
            @report_name 文件名
            @content 文件内容
            return:
            @msg 信息
            @flag 状态
            @url url地址
        """
        msg = "success"
        flag = True
        url = "" 
        if group_name == "" or report_name == "":
            msg = "group_name or report_name is empty"
            flag = False
            return flag, msg, url
        group_dir = self._check_group(group_name)
        log.info("group_dir:{}".format(group_dir))
        try:
            with open("%s/%s" % (group_dir, report_name), "w") as f:
                f.write(content.encode("utf8"))
            url = "%s/%s/%s" % (self.domain, group_name, report_name)
        except Exception as e:
            log.error(str(e))
            msg = str(e)
            flag = False
        return flag, msg, url
    
    def _push_dir(self, group_name, dir_name):
        """
            目录存储
            @group_name 分组名
            @dir_name 目录名
            return:
            @msg 信息
            @flag 状态
            @url url地址
        """
        msg = "success"
        flag = True
        url = ""
        group_dir = self._check_group(group_name)
        try:
           #remotefile.upload("xreport/{}".format(group_name), dir_name) 
           d = dir_name.strip(".").split("/")[-1]
           remotefile.download2("xreport/{}".format(group_name), d, os.path.join(group_dir, d))
           url = "{}/{}/{}".format(self.domain, group_name, d)
        except Exception as e:
            log.error(str(e))
            msg = str(e)
            flag = False
        return flag, msg, url


def run():
    if len(sys.argv) != 3:
        log.error("usage:python RpcServer.py ip port")
        sys.exit(1)
    rpc_ip = sys.argv[1]
    #default port: 5018
    rpc_port = int(sys.argv[2])
    folder = "/apsarapangu/disk1/xreport"
    domain = "http://xreport.alibaba-inc.com"
    try:
        rpc_obj = RpcServer(folder, domain)
        rpc = SimpleXMLRPCServer((rpc_ip, rpc_port))
        rpc.register_function(rpc_obj.save_report)
        rpc.serve_forever()
    except Exception as e:
        log.error(str(e))
        sys.exit(1)


if __name__ == "__main__":
    run()
